# 🛍️ Soko — Backend Integration Guide & Prompts

Your shop is **already working** with a built-in backend (Node + Express + JSON file).
This guide shows how to upgrade it step-by-step without breaking anything.

---

## ✅ What you have now (Option 0 — Built-in, Free)

| Layer | Tech |
|---|---|
| Frontend | HTML + CSS + Vanilla JS (`public/index.html`) |
| Backend | Node.js + Express (`server.js`) |
| Database | `data/products.json` (auto-seeded) |
| Images | `uploads/` folder via Multer |
| API | `GET /api/products`, `POST /api/products`, `DELETE /api/products/:id`, `POST /api/upload` |

**Run it:**
```bash
cd ecommerce-shop
npm install
npm start
# open http://localhost:3000
```

**Pros:** Zero cost, zero setup, works offline, perfect for testing.
**Cons:** Data resets if file is deleted, not multi-device, no real payments/login yet.

👉 **Stay here until you have real users, then pick one upgrade below.**

---

## 🚀 Upgrade Options (pick ONE to start)

### Option 1 — Supabase (RECOMMENDED ⭐)
Postgres database + image storage + auth, free tier generous. Best for Kenya/global scaling.

**Setup (10 min):**
1. Go to [supabase.com](https://supabase.com) → New Project
2. Create table `products` (id text, title text, price int, category text, description text, image text, seller text, location text, condition text, created_at timestamptz)
3. Create Storage bucket `product-images` (public)
4. Copy Project URL + anon key into `.env`

**Copy-paste prompt to migrate:**
```
Migrate my Soko shop backend from JSON file to Supabase.

Current API:
- GET /api/products?search=&category=&sort=
- POST /api/products {title, price, category, description, image, seller, location, condition}
- POST /api/upload (multipart image)
- DELETE /api/products/:id

Tasks:
1. Install @supabase/supabase-js and dotenv
2. Create supabase client in server.js using SUPABASE_URL and SUPABASE_ANON_KEY from .env
3. Replace readProducts/writeProducts with Supabase queries on table `products`
4. Replace multer local upload with Supabase Storage upload to bucket `product-images`, return public URL
5. Keep the exact same API responses so frontend doesn't change
6. Add .env.example and update README with setup steps
7. Test: list, search, filter, create product with image upload
```

---

### Option 2 — Firebase (Fastest to launch)
Firestore + Firebase Storage + Auth. Great if you want Google login.

**Setup:**
1. [console.firebase.google.com](https://console.firebase.google.com) → Create project
2. Enable Firestore + Storage
3. Create `firebaseConfig` in frontend

**Copy-paste prompt:**
```
Migrate Soko shop to Firebase.

Replace Express JSON storage with Firestore collection `products` and Firebase Storage for images.

Tasks:
1. Install firebase, dotenv
2. Initialize Firebase Admin SDK in server.js (or use client SDK in frontend)
3. Implement GET/POST/DELETE /api/products using Firestore
4. Implement POST /api/upload using Firebase Storage, return download URL
5. Keep frontend API calls unchanged (still fetch /api/products)
6. Add rules: public read, authenticated write (start open for demo)
7. Provide step-by-step Firebase console setup + .env.example
```

---

### Option 3 — MongoDB Atlas + Cloudinary (Classic MERN path)
Best if you want full control + MongoDB skills.

**Setup:**
1. [mongodb.com/atlas](https://www.mongodb.com/atlas) → Free cluster → get connection string
2. [cloudinary.com](https://cloudinary.com) → free account → get cloud name/key/secret

**Copy-paste prompt:**
```
Migrate Soko shop to MongoDB Atlas + Cloudinary.

Tasks:
1. Install mongoose, cloudinary, dotenv
2. Create Product model: title, price, category, description, image, seller, location, condition, createdAt
3. Connect mongoose to MONGO_URI from .env
4. Replace JSON storage with mongoose queries, keep same REST API
5. Replace multer disk storage with Cloudinary upload (multer-storage-cloudinary or direct upload), return secure_url as image
6. Add indexes on title/category for search
7. Provide .env.example and Atlas setup instructions
```

---

### Option 4 — SQLite (Simple upgrade, still free & local)
Keep single-file DB, add real SQL. Good middle ground before cloud.

**Copy-paste prompt:**
```
Migrate Soko shop JSON storage to SQLite using better-sqlite3.

Tasks:
1. Install better-sqlite3
2. Create products table matching current JSON fields
3. Replace readProducts/writeProducts with SQL queries
4. Keep API identical, add migration script to import existing products.json
5. Keep image uploads in /uploads as-is
```

---

## 💳 Payments (add after backend upgrade)

### Stripe (cards globally)
**Prompt:**
```
Add Stripe checkout to Soko shop.

Tasks:
1. Install stripe, create checkout session on POST /api/checkout {items:[{id,qty}]}
2. Frontend: replace demo checkout() with redirect to Stripe Checkout URL
3. Add webhook POST /api/webhook to confirm payment and mark order paid
4. Use STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET from .env
5. Keep demo mode if keys missing
```

### M-Pesa Daraja (Kenya ⭐)
**Prompt:**
```
Add M-Pesa Daraja STK Push payment to Soko shop.

Tasks:
1. Implement POST /api/mpesa/stk {phone, amount} using Daraja API (OAuth token + STK push)
2. Frontend checkout: ask for phone number, trigger STK push, show "Enter PIN on your phone"
3. Add callback endpoint POST /api/mpesa/callback to confirm payment
4. Use MPESA_CONSUMER_KEY, MPESA_CONSUMER_SECRET, MPESA_SHORTCODE, MPESA_PASSKEY from .env
5. Validate Kenyan phone format (07XX / 2547XX)
6. Provide Daraja test credentials setup guide
```

---

## 🔐 Auth / User Accounts (next upgrade)
**Prompt:**
```
Add user authentication to Soko shop.

Tasks:
1. Add POST /api/auth/register and POST /api/auth/login with bcrypt + JWT
2. Store users in same DB (Supabase/Firebase/Mongo)
3. Frontend: login/register modal, save JWT in localStorage, show seller name when logged in
4. Only logged-in users can POST /api/products; only owner can DELETE their products
5. Add "My Listings" filter
```

---

## ☁️ Deploy (free)
- **Frontend+Backend together:** Render.com / Railway.app / Fly.io (free tier)
- **Frontend only:** Vercel / Netlify
- **Prompt:**
```
Deploy Soko shop to Render.com.

Tasks:
1. Add render.yaml or Dockerfile
2. Ensure server binds to 0.0.0.0:$PORT (already done)
3. Add health check GET /api/health (already exists)
4. List required env vars and build/start commands
5. Test deployment checklist
```

---

## 🗺️ Recommended Roadmap

```
Week 1: Use built-in backend, get feedback, add real products
Week 2: Migrate to Supabase (Option 1) + deploy to Render
Week 3: Add M-Pesa Daraja payments
Week 4: Add auth + "My Listings" + WhatsApp seller contact button
Later:  Order tracking, seller dashboard, delivery fees, ratings
```

---

## 📁 Project Structure
```
ecommerce-shop/
├── server.js          ← Backend API
├── package.json
├── public/index.html  ← Frontend (shop + sell form + cart)
├── data/products.json ← Database (built-in mode)
├── uploads/           ← Uploaded photos
└── BACKEND_GUIDE.md   ← This file
```
