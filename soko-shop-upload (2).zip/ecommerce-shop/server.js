// Simple Shop - Full Stack Backend (Node + Express)
// Storage: JSON file (upgradeable to DB - see BACKEND_GUIDE.md)
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_FILE = path.join(__dirname, 'data', 'products.json');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(path.dirname(DATA_FILE))) fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });

// --- Seed data ---
function seed() {
  if (fs.existsSync(DATA_FILE)) return;
  const seedProducts = [
    { id: 'p1', title: 'Vintage Leather Jacket', price: 4500, category: 'Fashion', description: 'Genuine leather jacket, size M. Worn twice, like new. Nairobi delivery available.', image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80', seller: 'Amina K.', location: 'Nairobi', condition: 'Like New', createdAt: Date.now() - 86400000*2 },
    { id: 'p2', title: 'iPhone 13 - 128GB', price: 38000, category: 'Electronics', description: 'Battery health 91%. Includes charger and cover. No scratches.', image: 'https://images.unsplash.com/photo-1592750475338-74cb14b21085?w=800&q=80', seller: 'Brian O.', location: 'Westlands', condition: 'Used - Good', createdAt: Date.now() - 86400000 },
    { id: 'p3', title: 'Handmade Maasai Beadwork', price: 1200, category: 'Handmade', description: 'Beautiful traditional bead necklace made by local artisans. One of a kind.', image: 'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=800&q=80', seller: 'Wanjiru Crafts', location: 'Karen', condition: 'New', createdAt: Date.now() - 3600000*5 },
    { id: 'p4', title: 'Mountain Bike 27.5"', price: 22000, category: 'Sports', description: '21-speed, disc brakes, recently serviced. Ready for trails.', image: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=800&q=80', seller: 'Kevin M.', location: 'Rongai', condition: 'Used - Good', createdAt: Date.now() - 3600000*2 },
    { id: 'p5', title: 'Organic Honey - 500ml', price: 650, category: 'Food & Drink', description: 'Raw, unprocessed honey from Baringo. Pure and natural.', image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&q=80', seller: 'Baringo Farms', location: 'Nakuru', condition: 'New', createdAt: Date.now() },
    { id: 'p6', title: 'Sofa 3-Seater - Grey', price: 28000, category: 'Home & Living', description: 'Comfortable fabric sofa, solid wood frame. Selling due to relocation.', image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80', seller: 'Sarah N.', location: 'Kilimani', condition: 'Used - Good', createdAt: Date.now() - 3600000*8 },
  ];
  fs.writeFileSync(DATA_FILE, JSON.stringify(seedProducts, null, 2));
}
seed();

function readProducts() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return []; }
}
function writeProducts(p) { fs.writeFileSync(DATA_FILE, JSON.stringify(p, null, 2)); }

// --- Middleware ---
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname, 'public')));

// --- Image upload ---
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, Date.now() + '-' + Math.round(Math.random()*1e9) + ext);
  }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } }); // 5MB

app.post('/api/upload', upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded' });
  res.json({ url: '/uploads/' + req.file.filename });
});

// --- Products API ---
app.get('/api/products', (req, res) => {
  let products = readProducts();
  const { search, category, sort, maxPrice } = req.query;
  if (search) {
    const q = search.toLowerCase();
    products = products.filter(p => (p.title + ' ' + p.description + ' ' + p.category).toLowerCase().includes(q));
  }
  if (category && category !== 'All') products = products.filter(p => p.category === category);
  if (maxPrice) products = products.filter(p => p.price <= Number(maxPrice));
  if (sort === 'low') products.sort((a,b) => a.price - b.price);
  if (sort === 'high') products.sort((a,b) => b.price - a.price);
  if (sort === 'new') products.sort((a,b) => b.createdAt - a.createdAt);
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const p = readProducts().find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

app.post('/api/products', (req, res) => {
  const { title, price, category, description, image, seller, location, condition } = req.body;
  if (!title || !price || !description) return res.status(400).json({ error: 'Title, price and description are required' });
  const product = {
    id: 'p' + Date.now(),
    title: String(title).slice(0,120),
    price: Number(price),
    category: category || 'Other',
    description: String(description).slice(0,2000),
    image: image || 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80',
    seller: seller || 'Anonymous Seller',
    location: location || 'Nairobi',
    condition: condition || 'Used - Good',
    createdAt: Date.now()
  };
  const all = readProducts();
  all.unshift(product);
  writeProducts(all);
  res.status(201).json(product);
});

app.delete('/api/products/:id', (req, res) => {
  const all = readProducts();
  const filtered = all.filter(p => p.id !== req.params.id);
  writeProducts(filtered);
  res.json({ ok: true });
});

// Health
app.get('/api/health', (req,res)=> res.json({ ok:true, count: readProducts().length }));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🛍️  Simple Shop running at http://0.0.0.0:${PORT}`);
});
