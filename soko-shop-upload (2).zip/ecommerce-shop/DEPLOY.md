# 🚀 Deploy Soko Shop to the Internet (Free)

Your shop runs on your computer now. To give it a public link anyone can open, deploy it free on Render.com in ~5 minutes.

## What "deploy" means (layman's terms)
Right now your shop lives on *my* computer. Deploying = moving it to a computer on the internet that never sleeps, so your friends can visit `https://soko-shop.onrender.com` from their phones.

## Steps (Render.com — free tier)

1. **Push code to GitHub** (or upload zip)
   - Create a GitHub repo, upload the `ecommerce-shop` folder
   - Make sure `.env` is NOT uploaded (it's in `.gitignore` — check!)

2. **Create Render account** → [render.com](https://render.com) → Sign up free

3. **New Web Service**
   - Dashboard → **New** → **Web Service** → Connect your GitHub repo
   - Name: `soko-shop`
   - Runtime: **Node**
   - Build Command: `npm install`
   - Start Command: `node server.supabase.js`
   - Health Check Path: `/api/health`

4. **Add environment variables** (Render → your service → Environment)
   ```
   SUPABASE_URL = https://gumtsqdzygvmiglyzwrc.supabase.co
   SUPABASE_ANON_KEY = sb_publishable_...
   SUPABASE_SERVICE_KEY = sb_publishable_... (or your secret key)
   PORT = 10000
   ```
   ⚠️ Copy these from your local `.env` file — never share them publicly.

5. **Create Web Service** → wait 2-3 min → your link appears!
   - Example: `https://soko-shop.onrender.com`
   - Share this link for your presentation 🎉

## Alternative: Railway.app
Same steps: New Project → Deploy from GitHub → add env vars → get public URL.

## After deploying
- Test: open the link on your phone, post an item, check it appears in Supabase Table Editor
- Free tier sleeps after 15 min idle — first visit takes ~30 sec to wake up (normal!)
- Upgrade to paid ($7/mo) to keep it always awake

## Checklist before presenting
- [ ] Shop name/logo looks good
- [ ] 3-5 real products listed (delete demo ones you don't want)
- [ ] Post a test item with a real photo
- [ ] Open the public link on your phone — works?
- [ ] Preview video ready (`video/soko-preview.mp4`)
