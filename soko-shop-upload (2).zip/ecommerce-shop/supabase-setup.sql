-- Run this in Supabase Dashboard → SQL Editor → New Query → Run
-- Creates the products table for Soko shop

create table if not exists public.products (
  id text primary key,
  title text not null,
  price int not null,
  category text default 'Other',
  description text not null,
  image text,
  seller text default 'Anonymous Seller',
  location text default 'Nairobi',
  condition text default 'Used - Good',
  created_at bigint not null default (extract(epoch from now()) * 1000)::bigint
);

-- Enable Row Level Security (we'll allow public read/write for demo, tighten later with auth)
alter table public.products enable row level security;

-- Allow anyone to read/write (demo mode — replace with auth policies later)
create policy "public read" on public.products for select using (true);
create policy "public insert" on public.products for insert with check (true);
create policy "public update" on public.products for update using (true);
create policy "public delete" on public.products for delete using (true);

-- Storage bucket for product images (create via Dashboard → Storage → New bucket, or run this)
-- Note: bucket creation via SQL requires storage schema access; if this fails, create bucket manually:
-- Dashboard → Storage → New bucket → Name: product-images → Public: ON
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

-- Storage policies: public read, public upload (demo)
create policy "public read images" on storage.objects for select using (bucket_id = 'product-images');
create policy "public upload images" on storage.objects for insert with check (bucket_id = 'product-images');
create policy "public update images" on storage.objects for update using (bucket_id = 'product-images');
create policy "public delete images" on storage.objects for delete using (bucket_id = 'product-images');

-- Seed demo products (optional — run once)
insert into public.products (id, title, price, category, description, image, seller, location, condition, created_at) values
('p1', 'Vintage Leather Jacket', 4500, 'Fashion', 'Genuine leather jacket, size M. Worn twice, like new. Nairobi delivery available.', 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&q=80', 'Amina K.', 'Nairobi', 'Like New', 1795514779498),
('p2', 'iPhone 13 - 128GB', 38000, 'Electronics', 'Battery health 91%. Includes charger and cover. No scratches.', 'https://images.unsplash.com/photo-1592750475338-74cb14b21085?w=800&q=80', 'Brian O.', 'Westlands', 'Used - Good', 1795514779499),
('p3', 'Handmade Maasai Beadwork', 1200, 'Handmade', 'Beautiful traditional bead necklace made by local artisans. One of a kind.', 'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=800&q=80', 'Wanjiru Crafts', 'Karen', 'New', 1795514779500),
('p4', 'Mountain Bike 27.5"', 22000, 'Sports', '21-speed, disc brakes, recently serviced. Ready for trails.', 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=800&q=80', 'Kevin M.', 'Rongai', 'Used - Good', 1795514779501),
('p5', 'Organic Honey - 500ml', 650, 'Food & Drink', 'Raw, unprocessed honey from Baringo. Pure and natural.', 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&q=80', 'Baringo Farms', 'Nakuru', 'New', 1795514779502),
('p6', 'Sofa 3-Seater - Grey', 28000, 'Home & Living', 'Comfortable fabric sofa, solid wood frame. Selling due to relocation.', 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80', 'Sarah N.', 'Kilimani', 'Used - Good', 1795514779503)
on conflict (id) do nothing;
