// Soko Shop — Supabase Backend (Node + Express + Supabase)
// Falls back to JSON file if SUPABASE_URL is not set (so shop never breaks)
require('dotenv').config();
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');
const ws = require('ws');
global.WebSocket = ws;

const app = express();
const PORT = process.env.PORT || 3000;

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;

let supabase = null;
let useSupabase = false;
if (SUPABASE_URL && SUPABASE_ANON_KEY) {
  // Use service key if available (server-side, bypasses RLS), else anon key
  supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY || SUPABASE_ANON_KEY, { global: { WebSocket: ws } });
  useSupabase = true;
  console.log('✅ Supabase connected:', SUPABASE_URL);
} else {
  console.log('⚠️  SUPABASE_URL not set — using local JSON fallback. Add .env to enable Supabase.');
}

// --- JSON fallback (only used when Supabase not configured) ---
const DATA_FILE = path.join(__dirname, 'data', 'products.json');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(path.dirname(DATA_FILE))) fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
function readProductsJSON() { try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return []; } }
function writeProductsJSON(p) { fs.writeFileSync(DATA_FILE, JSON.stringify(p, null, 2)); }

// --- Middleware ---
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname, 'public')));

// --- Image upload (memory storage for Supabase, disk for fallback) ---
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

app.post('/api/upload', upload.single('image'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded' });
  if (useSupabase) {
    try {
      const ext = path.extname(req.file.originalname) || '.jpg';
      const filename = Date.now() + '-' + Math.round(Math.random()*1e9) + ext;
      const { error } = await supabase.storage.from('product-images').upload(filename, req.file.buffer, { contentType: req.file.mimetype, upsert: false });
      if (error) throw error;
      const { data } = supabase.storage.from('product-images').getPublicUrl(filename);
      return res.json({ url: data.publicUrl });
    } catch (e) {
      console.error('Supabase upload error:', e.message);
      return res.status(500).json({ error: 'Upload failed: ' + e.message });
    }
  } else {
    // Fallback: save to disk
    const ext = path.extname(req.file.originalname) || '.jpg';
    const filename = Date.now() + '-' + Math.round(Math.random()*1e9) + ext;
    fs.writeFileSync(path.join(UPLOAD_DIR, filename), req.file.buffer);
    return res.json({ url: '/uploads/' + filename });
  }
});

// --- Products API ---
app.get('/api/products', async (req, res) => {
  const { search, category, sort, maxPrice } = req.query;
  try {
    if (useSupabase) {
      let query = supabase.from('products').select('*');
      if (category && category !== 'All') query = query.eq('category', category);
      if (maxPrice) query = query.lte('price', Number(maxPrice));
      if (search) query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%,category.ilike.%${search}%`);
      if (sort === 'low') query = query.order('price', { ascending: true });
      else if (sort === 'high') query = query.order('price', { ascending: false });
      else query = query.order('created_at', { ascending: false });
      const { data, error } = await query;
      if (error) throw error;
      return res.json(data || []);
    } else {
      let products = readProductsJSON();
      if (search) { const q = search.toLowerCase(); products = products.filter(p => (p.title + ' ' + p.description + ' ' + p.category).toLowerCase().includes(q)); }
      if (category && category !== 'All') products = products.filter(p => p.category === category);
      if (maxPrice) products = products.filter(p => p.price <= Number(maxPrice));
      if (sort === 'low') products.sort((a,b) => a.price - b.price);
      if (sort === 'high') products.sort((a,b) => b.price - a.price);
      if (sort === 'new') products.sort((a,b) => b.createdAt - a.createdAt);
      return res.json(products);
    }
  } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
});

app.get('/api/products/:id', async (req, res) => {
  try {
    if (useSupabase) {
      const { data, error } = await supabase.from('products').select('*').eq('id', req.params.id).single();
      if (error || !data) return res.status(404).json({ error: 'Not found' });
      return res.json(data);
    } else {
      const p = readProductsJSON().find(x => x.id === req.params.id);
      if (!p) return res.status(404).json({ error: 'Not found' });
      return res.json(p);
    }
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/products', async (req, res) => {
  const { title, price, category, description, image, seller, location, condition } = req.body;
  if (!title || !price || !description) return res.status(400).json({ error: 'Title, price and description are required' });
  const product = {
    id: 'p' + Date.now(),
    title: String(title).slice(0,120),
    price: Number(price),
    category: category || 'Other',
    description: String(description).slice(0,2000),
    image: image || 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80',
    seller: seller || 'Anonymous Seller',
    location: location || 'Nairobi',
    condition: condition || 'Used - Good',
    created_at: Date.now()
  };
  // Keep camelCase alias for frontend compatibility
  const productOut = { ...product, createdAt: product.created_at };
  try {
    if (useSupabase) {
      const { data, error } = await supabase.from('products').insert([product]).select().single();
      if (error) throw error;
      return res.status(201).json({ ...data, createdAt: data.created_at });
    } else {
      const all = readProductsJSON(); all.unshift(productOut); writeProductsJSON(all);
      return res.status(201).json(productOut);
    }
  } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
});

app.delete('/api/products/:id', async (req, res) => {
  try {
    if (useSupabase) {
      const { error } = await supabase.from('products').delete().eq('id', req.params.id);
      if (error) throw error;
    } else {
      writeProductsJSON(readProductsJSON().filter(p => p.id !== req.params.id));
    }
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/health', async (req, res) => {
  if (useSupabase) {
    const { count } = await supabase.from('products').select('*', { count: 'exact', head: true });
    return res.json({ ok: true, backend: 'supabase', count: count || 0 });
  }
  return res.json({ ok: true, backend: 'json-fallback', count: readProductsJSON().length });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🛍️  Soko Shop running at http://0.0.0.0:${PORT} (backend: ${useSupabase ? 'Supabase' : 'JSON fallback'})`);
});
